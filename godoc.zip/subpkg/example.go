package subpkg

// PlusOne ...
func PlusOne(x int) int {
	return x + 1
}
